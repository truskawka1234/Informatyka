function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 Projekt React — Wiktoria</p>
    </footer>
  );
}

export default Footer;
