import React, { useEffect, useState } from "react";

const LOAD_STEP = 6;

function Gallery() {
  const [allBreeds, setAllBreeds] = useState([]);
  const [images, setImages] = useState([]);
  const [displayCount, setDisplayCount] = useState(LOAD_STEP);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);

  useEffect(() => {
    fetch("https://dog.ceo/api/breeds/list/all")
      .then(res => res.json())
      .then(data => {
        const breeds = Object.keys(data.message);
        setAllBreeds(breeds);
      });
  }, []);

  useEffect(() => {
    if (allBreeds.length === 0) return;
    setLoading(true);

    const breedsToLoad = allBreeds.slice(0, displayCount);

    const promises = breedsToLoad.map(breed =>
      fetch(`https://dog.ceo/api/breed/${breed}/images/random`)
        .then(res => res.json())
        .then(data => ({ breed, url: data.message }))
        .catch(() => ({ breed, url: null }))
    );

    Promise.all(promises).then(results => {
      setImages(results);
      setLoading(false);
      setLoadingMore(false);
    });
  }, [allBreeds, displayCount]);

  const handleLoadMore = () => {
    setLoadingMore(true);
    setDisplayCount(prev => Math.min(prev + LOAD_STEP, allBreeds.length));
  };

  return (
    <div className="gallery">
      <h1>Galeria ras</h1>

      {loading ? (
        <p>Ładowanie zdjęć...</p>
      ) : (
        <>
          <div className="gallery__grid">
            {images.map(({ breed, url }) => (
              <div key={breed} className="gallery__item">
                <img src={url || "https://via.placeholder.com/250x180?text=Brak+zdjęcia"} alt={breed} />
                <p>{breed}</p>
              </div>
            ))}
          </div>

          {displayCount < allBreeds.length && (
            <button onClick={handleLoadMore} disabled={loadingMore} className="gallery__load-more">
              {loadingMore ? "Ładowanie..." : "Załaduj więcej"}
            </button>
          )}
        </>
      )}
    </div>
  );
}

export default Gallery;
