import React from "react";


function Care() {
  const topics = [
    {
      title: "Żywienie",
      content:
        "Psy potrzebują zbilansowanej diety bogatej w białko. Unikaj podawania czekolady, winogron, cebuli i przyprawionych potraw.",
    },
    {
      title: "Higiena",
      content:
        "Regularnie kąp swojego psa (co 1–2 miesiące), czyść uszy i przycinaj pazury. Używaj specjalnych kosmetyków dla psów.",
    },
    {
      title: "Aktywność fizyczna",
      content:
        "Psy potrzebują codziennych spacerów i zabawy. Rasy energiczne, jak husky czy border collie, wymagają więcej ruchu.",
    },
    {
      title: "Zdrowie",
      content:
        "Nie zapominaj o szczepieniach i odrobaczaniu. Regularne wizyty u weterynarza pomagają wcześnie wykryć problemy.",
    },
    {
      title: "Pielęgnacja sierści",
      content:
        "Niektóre psy linieją intensywniej (np. labradory), inne trzeba regularnie strzyc (np. pudle). Czesać warto co kilka dni.",
    },
  ];

  return (
    <div className="care">
      <h1>Opieka nad psem</h1>
      <div className="care__list">
        {topics.map((topic, index) => (
          <div className="care__card" key={index}>
            <h2>{topic.title}</h2>
            <p>{topic.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Care;
