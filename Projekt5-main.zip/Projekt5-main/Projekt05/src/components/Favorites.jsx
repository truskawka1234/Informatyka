import React, { useEffect, useState } from "react";

function Favorites() {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem("favorites");
    if (stored) {
      setFavorites(JSON.parse(stored));
    }
  }, []);

  if (favorites.length === 0) {
    return <p className="favorites__empty">Brak ulubionych ras.</p>;
  }

  return (
    <div className="favorites">
      <h1>Twoje ulubione rasy</h1>
      <div className="favorites__list">
        {favorites.map((fav, index) => (
          <div key={index} className="favorites__item">
            <img src={fav.imageUrl} alt={fav.name} />
            <h3>{fav.name}</h3>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Favorites;
