import React from "react";

function Breed({ name, imageUrl, specs }) {
  const handleAddToFavorites = () => {
    const existing = JSON.parse(localStorage.getItem("favorites")) || [];
    const isAlready = existing.some((fav) => fav.name === name);
    if (!isAlready) {
      const updated = [...existing, { name, imageUrl }];
      localStorage.setItem("favorites", JSON.stringify(updated));
    }
  };

  return (
    <div className="breed-card">
      <h2 className="breed-card__name">{name}</h2>
      <img src={imageUrl} alt={name} className="breed-card__image" loading="lazy" />
      <div className="breed-card__specs">
        <p>Długość życia: {specs.lifeSpan || "Brak danych"}</p>
        <p>Wielkość: {specs.size || "Brak danych"}</p>
        <p>Temperament: {specs.temperament || "Brak danych"}</p>
      </div>
      <button onClick={handleAddToFavorites} className="breed-card__fav-btn">❤️ Dodaj do ulubionych</button>
    </div>
  );
}

export default Breed;
