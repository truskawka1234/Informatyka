import React from "react";

function Home() {
  return (
    <div className="home">
      <h1 className="home__title">Witaj na stronie o psach!</h1>
      <p className="home__description">
        Znajdziesz tutaj informacje o różnych rasach psów, galerię zdjęć, quiz i wiele więcej.
      </p>
      <div className="home__image-wrapper">
        <img
          src="https://images.unsplash.com/photo-1517423440428-a5a00ad493e8?auto=format&fit=crop&w=800&q=80"
          alt="Pieski"
          className="home__image"
          loading="lazy"
        />
      </div>
    </div>
  );
}

export default Home;
