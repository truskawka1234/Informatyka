import React, { useState, useEffect } from "react";
import Breed from "./Breed";

const breedSpecs = {
  bulldog: {
    lifeSpan: "8-10 lat",
    size: "Średni",
    temperament: "Łagodny, uparty, przyjazny",
  },
  beagle: {
    lifeSpan: "12-15 lat",
    size: "Mały/średni",
    temperament: "Łagodny, inteligentny, spokojny",
  },
  poodle: {
    lifeSpan: "10-18 lat",
    size: "Mały do średniego",
    temperament: "Inteligentny, energiczny, towarzyski",
  },
  labrador: {
    lifeSpan: "10-12 lat",
    size: "Średni do dużego",
    temperament: "Przyjazny, aktywny, posłuszny",
  },
  chihuahua: {
    lifeSpan: "14-16 lat",
    size: "Bardzo mały",
    temperament: "Odważny, czujny, lojalny",
  },
  husky: {
    lifeSpan: "12-15 lat",
    size: "Średni do dużego",
    temperament: "Energetyczny, przyjazny, niezależny",
  },
  dachshund: {
    lifeSpan: "12-16 lat",
    size: "Mały",
    temperament: "Czujny, odważny, uparty",
  },
  boxer: {
    lifeSpan: "9-12 lat",
    size: "Średni do dużego",
    temperament: "Aktywny, czujny, lojalny",
  },
  "boston bulldog": {
    lifeSpan: "11-13 lat",
    size: "Mały/średni",
    temperament: "Energetyczny, inteligentny, czujny",
  },
  "german shepherd": {
    lifeSpan: "9-13 lat",
    size: "Duży",
    temperament: "Inteligentny, lojalny, czujny",
  },
  "golden retriever": {
    lifeSpan: "10-12 lat",
    size: "Duży",
    temperament: "Przyjazny, inteligentny, łagodny",
  },
  "shih tzu": {
    lifeSpan: "10-16 lat",
    size: "Mały",
    temperament: "Towarzyski, uroczy, łagodny",
  },
  "french bulldog": {
    lifeSpan: "10-12 lat",
    size: "Mały",
    temperament: "Towarzyski, czujny, wesoły",
  },
  // Dodaj więcej, jeśli chcesz
};

function Breeds() {
  const [allBreeds, setAllBreeds] = useState([]);
  const [displayedBreeds, setDisplayedBreeds] = useState([]);
  const [breedImages, setBreedImages] = useState({});
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const loadStep = 10; // ile ras ładować za jednym razem

  useEffect(() => {
    fetch("https://dog.ceo/api/breeds/list/all")
      .then((res) => res.json())
      .then((data) => {
        const list = [];
        for (const breed in data.message) {
          if (data.message[breed].length === 0) {
            list.push(breed);
          } else {
            data.message[breed].forEach((sub) => list.push(`${sub} ${breed}`));
          }
        }
        setAllBreeds(list);
        setDisplayedBreeds(list.slice(0, loadStep));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (displayedBreeds.length === 0) return;

    setLoadingMore(true);

    const promises = displayedBreeds.map((breed) => {
      const apiBreedName = breed.includes(" ")
        ? breed.split(" ").reverse().join("/")
        : breed;

      return fetch(`https://dog.ceo/api/breed/${apiBreedName}/images/random`)
        .then((res) => res.json())
        .then((data) => ({ breed, imageUrl: data.message }))
        .catch(() => ({ breed, imageUrl: null }));
    });

    Promise.all(promises).then((results) => {
      setBreedImages((prev) => {
        const newImages = { ...prev };
        results.forEach(({ breed, imageUrl }) => {
          if (imageUrl) newImages[breed] = imageUrl;
        });
        return newImages;
      });
      setLoadingMore(false);
    });
  }, [displayedBreeds]);

  const handleLoadMore = () => {
    const next = allBreeds.slice(displayedBreeds.length, displayedBreeds.length + loadStep);
    setDisplayedBreeds([...displayedBreeds, ...next]);
  };

  if (loading) return <p>Ładowanie ras psów...</p>;

  return (
    <div className="breeds">
      <h1>Rasy psów</h1>
      <div className="breeds__list">
        {displayedBreeds.map((breed) => {
          // specs: jeśli podrasa, to bierzemy specs głównej rasy (ostatnie słowo)
          const mainBreed = breed.includes(" ") ? breed.split(" ")[1] : breed;
          const specs = breedSpecs[mainBreed] || {};

          return (
            <Breed
              key={breed}
              name={breed}
              imageUrl={breedImages[breed] || "https://via.placeholder.com/220x160?text=Brak+zdjęcia"}
              specs={specs}
            />
          );
        })}
      </div>
      {displayedBreeds.length < allBreeds.length && (
        <button
          onClick={handleLoadMore}
          disabled={loadingMore}
          className="breeds__load-more"
        >
          {loadingMore ? "Ładowanie..." : "Załaduj więcej"}
        </button>
      )}
    </div>
  );
}

export default Breeds;
