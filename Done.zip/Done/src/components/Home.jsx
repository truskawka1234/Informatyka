import React from "react";

function Home() {
  return <h1 id="glowna">Strona Glowna</h1>;
}

export default Home;
